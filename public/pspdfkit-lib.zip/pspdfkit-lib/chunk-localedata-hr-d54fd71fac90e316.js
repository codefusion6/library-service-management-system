/*!
 * PSPDFKit for Web 2024.1.1 (https://pspdfkit.com/web)
 *
 * Copyright (c) 2016-2024 PSPDFKit GmbH. All rights reserved.
 *
 * THIS SOURCE CODE AND ANY ACCOMPANYING DOCUMENTATION ARE PROTECTED BY INTERNATIONAL COPYRIGHT LAW
 * AND MAY NOT BE RESOLD OR REDISTRIBUTED. USAGE IS BOUND TO THE PSPDFKIT LICENSE AGREEMENT.
 * UNAUTHORIZED REPRODUCTION OR DISTRIBUTION IS SUBJECT TO CIVIL AND CRIMINAL PENALTIES.
 * This notice may not be removed from this file.
 *
 * PSPDFKit uses several open source third-party components: https://pspdfkit.com/acknowledgements/web/
 */
(self.webpackChunkPSPDFKit=self.webpackChunkPSPDFKit||[]).push([[9677],{7609:()=>{Intl.PluralRules&&"function"==typeof Intl.PluralRules.__addLocaleData&&Intl.PluralRules.__addLocaleData({data:{hr:{categories:{cardinal:["one","few","other"],ordinal:["other"]},fn:function(e,l){var a=String(e).split("."),t=a[0],n=a[1]||"",r=!a[1],i=t.slice(-1),o=t.slice(-2),c=n.slice(-1),s=n.slice(-2);return l?"other":r&&1==i&&11!=o||1==c&&11!=s?"one":r&&i>=2&&i<=4&&(o<12||o>14)||c>=2&&c<=4&&(s<12||s>14)?"few":"other"}}},availableLocales:["hr"]})}}]);